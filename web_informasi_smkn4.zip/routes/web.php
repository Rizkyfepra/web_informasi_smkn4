<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\GaleryController;
use App\Http\Controllers\HomeController;


Route::prefix('admin')->name('admin.')->group(function () {
    Route::resource('galleries', GaleryController::class);
});

Route::get('/', [HomeController::class, 'index']);