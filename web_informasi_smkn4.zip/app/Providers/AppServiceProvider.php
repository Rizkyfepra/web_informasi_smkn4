<?php

namespace App\Providers;

use App\Models\User;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // Cuma 1 email ini yang boleh akses CRUD galeri.
        // Ganti string di bawah sesuai email akun admin kamu.
        Gate::define('manage-gallery', function (User $user) {
            return $user->email === 'GANTI_DENGAN_EMAIL_ADMIN_KAMU@gmail.com';
        });
    }
}